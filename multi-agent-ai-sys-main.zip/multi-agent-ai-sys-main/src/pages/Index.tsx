import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AgentPipeline from "@/components/AgentPipeline";
import ResumeUpload from "@/components/ResumeUpload";
import SkillTaxonomy from "@/components/SkillTaxonomy";
import JobMatching from "@/components/JobMatching";
import ApiDocs from "@/components/ApiDocs";
import { Brain } from "lucide-react";

const Index = () => {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection onNavigate={scrollTo} />
      <AgentPipeline />
      <ResumeUpload />
      <SkillTaxonomy />
      <JobMatching />
      <ApiDocs />

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="section-container text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="w-6 h-6 rounded-md bg-primary/20 flex items-center justify-center">
              <Brain className="w-4 h-4 text-primary" />
            </div>
            <span className="font-semibold">TalentAI</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Multi-Agent AI System for Intelligent Resume Parsing & Talent Intelligence
          </p>
          <p className="text-xs text-muted-foreground mt-2">Hackathon Project 2026</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
