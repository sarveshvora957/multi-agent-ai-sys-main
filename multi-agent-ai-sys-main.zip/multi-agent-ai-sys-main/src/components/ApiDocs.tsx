import { Code2, Copy, Check } from "lucide-react";
import { useState } from "react";

const endpoints = [
  {
    method: "POST",
    path: "/api/v1/parse",
    description: "Parse a resume file and return structured data",
    body: `{
  "file": "<base64_encoded_file>",
  "format": "pdf",
  "options": {
    "extract_skills": true,
    "normalize": true
  }
}`,
    response: `{
  "status": "success",
  "data": {
    "personal": { "name": "Priya Sharma", ... },
    "skills": ["Python", "React.js", ...],
    "experience": [...],
    "education": [...]
  },
  "agent_metadata": {
    "parsing_time_ms": 342,
    "confidence": 0.94
  }
}`,
  },
  {
    method: "POST",
    path: "/api/v1/match",
    description: "Match candidate profile against job requirements",
    body: `{
  "candidate_id": "cand_abc123",
  "job_description": "We are looking for...",
  "threshold": 0.7,
  "weights": {
    "required_skills": 0.5,
    "experience": 0.3,
    "education": 0.2
  }
}`,
    response: `{
  "match_score": 0.87,
  "matched_skills": [...],
  "gaps": [...],
  "upskill_suggestions": [...]
}`,
  },
  {
    method: "GET",
    path: "/api/v1/taxonomy",
    description: "Retrieve the full skill taxonomy tree",
    body: null,
    response: `{
  "taxonomy": {
    "Technical Skills": {
      "Programming Languages": ["Python", "JS", ...],
      "ML/AI": ["TensorFlow", ...]
    }
  },
  "total_skills": 5247
}`,
  },
];

const methodColors: Record<string, string> = {
  GET: "bg-success/20 text-success",
  POST: "bg-primary/20 text-primary",
  PUT: "bg-warning/20 text-warning",
  DELETE: "bg-destructive/20 text-destructive",
};

const ApiDocs = () => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const copyCode = (code: string, idx: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <section id="api" className="py-24 bg-muted/20">
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 agent-badge border-primary/30 bg-primary/10 text-primary mb-4">
            <Code2 className="w-3.5 h-3.5" />
            REST API
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            API-Ready <span className="gradient-text">Integration</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Well-documented REST endpoints for seamless third-party integration.
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {endpoints.map((ep, idx) => (
            <div key={ep.path} className="glass-card overflow-hidden">
              <div className="px-6 py-4 border-b border-border flex items-center gap-3">
                <span className={`px-2.5 py-1 rounded text-xs font-bold ${methodColors[ep.method]}`}>{ep.method}</span>
                <code className="text-sm font-mono">{ep.path}</code>
              </div>
              <div className="p-6">
                <p className="text-sm text-muted-foreground mb-4">{ep.description}</p>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {ep.body && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-muted-foreground uppercase tracking-wider">Request Body</span>
                        <button
                          onClick={() => copyCode(ep.body!, idx)}
                          className="text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {copiedIdx === idx ? <Check className="w-3.5 h-3.5 text-success" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <pre className="bg-background/80 rounded-lg p-4 text-xs overflow-x-auto font-mono leading-relaxed">
                        {ep.body}
                      </pre>
                    </div>
                  )}
                  <div>
                    <span className="text-xs text-muted-foreground uppercase tracking-wider block mb-2">Response</span>
                    <pre className="bg-background/80 rounded-lg p-4 text-xs overflow-x-auto font-mono leading-relaxed">
                      {ep.response}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ApiDocs;
