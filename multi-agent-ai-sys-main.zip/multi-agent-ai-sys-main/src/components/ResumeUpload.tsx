import { useState, useCallback } from "react";
import { Upload, FileText, File, X, Loader2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

type UploadState = "idle" | "uploading" | "parsing" | "done";

interface ParsedResume {
  name: string;
  email: string;
  phone: string;
  location: string;
  skills: string[];
  experience: { company: string; role: string; duration: string }[];
  education: { institution: string; degree: string; year: string }[];
}

const MOCK_RESULT: ParsedResume = {
  name: "Priya Sharma",
  email: "priya.sharma@email.com",
  phone: "+91 98765 43210",
  location: "Ahmedabad, Gujarat",
  skills: ["React.js", "TypeScript", "Python", "TensorFlow", "Node.js", "PostgreSQL", "Docker", "AWS", "Machine Learning", "REST APIs"],
  experience: [
    { company: "TCS", role: "Senior Software Engineer", duration: "2021 - Present" },
    { company: "Infosys", role: "Software Developer", duration: "2018 - 2021" },
  ],
  education: [
    { institution: "IIT Gandhinagar", degree: "B.Tech Computer Science", year: "2018" },
  ],
};

const ResumeUpload = () => {
  const [state, setState] = useState<UploadState>("idle");
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<ParsedResume | null>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files[0];
    if (dropped) processFile(dropped);
  }, []);

  const processFile = (f: File) => {
    setFile(f);
    setState("uploading");
    setTimeout(() => {
      setState("parsing");
      setTimeout(() => {
        setState("done");
        setResult(MOCK_RESULT);
      }, 2000);
    }, 1500);
  };

  const reset = () => {
    setState("idle");
    setFile(null);
    setResult(null);
  };

  return (
    <section id="upload" className="py-24">
      <div className="section-container">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 agent-badge border-primary/30 bg-primary/10 text-primary mb-4">
            <Upload className="w-3.5 h-3.5" />
            Resume Parser
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Upload & <span className="gradient-text">Parse Resume</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Drop a resume in any format — our parsing agent extracts structured data instantly.
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload area */}
          <div className="glass-card p-6">
            {state === "idle" ? (
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                className="border-2 border-dashed border-border rounded-xl p-12 text-center cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => {
                  const input = document.createElement("input");
                  input.type = "file";
                  input.accept = ".pdf,.docx,.txt";
                  input.onchange = (e) => {
                    const f = (e.target as HTMLInputElement).files?.[0];
                    if (f) processFile(f);
                  };
                  input.click();
                }}
              >
                <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="font-medium mb-1">Drop resume here or click to browse</p>
                <p className="text-sm text-muted-foreground">PDF, DOCX, or TXT — up to 10MB</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
                  <FileText className="w-8 h-8 text-primary shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{file?.name}</p>
                    <p className="text-xs text-muted-foreground">{((file?.size || 0) / 1024).toFixed(1)} KB</p>
                  </div>
                  {state === "done" && (
                    <button onClick={reset} className="text-muted-foreground hover:text-foreground">
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Pipeline steps */}
                {["uploading", "parsing", "done"].map((step, i) => {
                  const steps = ["uploading", "parsing", "done"];
                  const currentIdx = steps.indexOf(state);
                  const stepIdx = i;
                  const labels = ["Uploading file...", "AI Agents parsing...", "Extraction complete"];
                  const isActive = stepIdx === currentIdx;
                  const isDone = stepIdx < currentIdx || state === "done";

                  return (
                    <div key={step} className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${isActive ? "bg-primary/10" : ""}`}>
                      {isDone ? (
                        <CheckCircle2 className="w-5 h-5 text-success shrink-0" />
                      ) : isActive ? (
                        <Loader2 className="w-5 h-5 text-primary animate-spin shrink-0" />
                      ) : (
                        <div className="w-5 h-5 rounded-full border border-border shrink-0" />
                      )}
                      <span className={`text-sm ${isDone ? "text-success" : isActive ? "text-foreground" : "text-muted-foreground"}`}>
                        {labels[i]}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Results */}
          <div className="glass-card p-6">
            <h3 className="text-lg font-semibold mb-4">Extracted Data</h3>
            {!result ? (
              <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                <File className="w-12 h-12 mb-3 opacity-40" />
                <p className="text-sm">Upload a resume to see parsed results</p>
              </div>
            ) : (
              <div className="space-y-4 animate-fade-in text-sm">
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider">Personal Info</label>
                  <div className="mt-1 space-y-1">
                    <p className="font-medium">{result.name}</p>
                    <p className="text-muted-foreground">{result.email}</p>
                    <p className="text-muted-foreground">{result.phone} • {result.location}</p>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider">Skills ({result.skills.length})</label>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {result.skills.map((s) => (
                      <span key={s} className="agent-badge border-primary/20 bg-primary/10 text-primary text-xs">{s}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider">Experience</label>
                  <div className="mt-2 space-y-2">
                    {result.experience.map((e) => (
                      <div key={e.company} className="p-2 rounded-lg bg-muted/50">
                        <p className="font-medium">{e.role}</p>
                        <p className="text-xs text-muted-foreground">{e.company} • {e.duration}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider">Education</label>
                  <div className="mt-2">
                    {result.education.map((e) => (
                      <div key={e.institution} className="p-2 rounded-lg bg-muted/50">
                        <p className="font-medium">{e.degree}</p>
                        <p className="text-xs text-muted-foreground">{e.institution} • {e.year}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResumeUpload;
