import { FileText, Tags, Target, Network, ArrowRight, CheckCircle2 } from "lucide-react";

const agents = [
  {
    icon: FileText,
    title: "Parsing Agent",
    description: "Multi-format resume extraction with NLP section detection and LLM-powered parsing for edge cases.",
    features: ["PDF / DOCX / TXT", "Layout analysis", "Section detection", "Entity extraction"],
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/20",
  },
  {
    icon: Tags,
    title: "Normalization Agent",
    description: "Maps extracted skills to hierarchical taxonomy with synonym resolution and proficiency estimation.",
    features: ["Skill taxonomy", "Synonym mapping", "Proficiency levels", "Emerging skills"],
    color: "text-secondary",
    bgColor: "bg-secondary/10",
    borderColor: "border-secondary/20",
  },
  {
    icon: Target,
    title: "Matching Agent",
    description: "Semantic similarity matching with vector embeddings, gap analysis, and configurable thresholds.",
    features: ["Vector matching", "Weighted scoring", "Gap analysis", "Configurable thresholds"],
    color: "text-info",
    bgColor: "bg-info/10",
    borderColor: "border-info/20",
  },
  {
    icon: Network,
    title: "Orchestration Layer",
    description: "Coordinates agents through shared protocol with retry logic, batch processing, and observability.",
    features: ["Task delegation", "Batch processing", "Retry logic", "Observability"],
    color: "text-warning",
    bgColor: "bg-warning/10",
    borderColor: "border-warning/20",
  },
];

const AgentPipeline = () => {
  return (
    <section id="agents" className="py-24">
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 agent-badge border-secondary/30 bg-secondary/10 text-secondary mb-4">
            <Network className="w-3.5 h-3.5" />
            Multi-Agent Architecture
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Four Specialized <span className="gradient-text">AI Agents</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Each agent handles a distinct phase of the talent intelligence pipeline, collaborating through a shared message protocol.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {agents.map((agent, idx) => (
            <div key={agent.title} className="relative">
              <div className={`glass-card p-6 h-full transition-all duration-300 hover:scale-[1.02] ${agent.borderColor} border`}>
                <div className={`w-12 h-12 rounded-xl ${agent.bgColor} flex items-center justify-center mb-4`}>
                  <agent.icon className={`w-6 h-6 ${agent.color}`} />
                </div>
                <div className="text-xs text-muted-foreground mb-2 font-medium uppercase tracking-wider">
                  Agent {idx + 1}
                </div>
                <h3 className="text-lg font-semibold mb-2">{agent.title}</h3>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{agent.description}</p>
                <ul className="space-y-2">
                  {agent.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className={`w-3.5 h-3.5 ${agent.color} shrink-0`} />
                      <span className="text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
              {idx < agents.length - 1 && (
                <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10">
                  <ArrowRight className="w-6 h-6 text-muted-foreground/40" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AgentPipeline;
