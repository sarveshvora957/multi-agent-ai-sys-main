import { Target, TrendingUp, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const matchResults = [
  {
    role: "Senior ML Engineer",
    company: "Google",
    score: 92,
    matched: ["Python", "TensorFlow", "Deep Learning", "Docker", "AWS"],
    missing: ["Spark"],
    partial: ["Kubernetes"],
  },
  {
    role: "Full Stack Developer",
    company: "Microsoft",
    score: 87,
    matched: ["React.js", "TypeScript", "Node.js", "PostgreSQL", "REST APIs"],
    missing: ["GraphQL", "Azure"],
    partial: ["CI/CD"],
  },
  {
    role: "AI Research Scientist",
    company: "OpenAI",
    score: 71,
    matched: ["Python", "TensorFlow", "PyTorch", "Machine Learning"],
    missing: ["Research Publications", "PhD"],
    partial: ["NLP", "Transformers"],
  },
];

const getScoreColor = (score: number) => {
  if (score >= 85) return "text-success";
  if (score >= 70) return "text-warning";
  return "text-destructive";
};

const JobMatching = () => {
  return (
    <section id="matching" className="py-24">
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 agent-badge border-info/30 bg-info/10 text-info mb-4">
            <Target className="w-3.5 h-3.5" />
            Semantic Matching
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Job <span className="gradient-text">Match Results</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Vector embedding-based matching with weighted scoring and gap analysis.
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {matchResults.map((job) => (
            <div key={job.role} className="glass-card p-6 hover:scale-[1.01] transition-transform">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-lg font-semibold">{job.role}</h3>
                  <p className="text-sm text-muted-foreground">{job.company}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${getScoreColor(job.score)}`}>{job.score}%</div>
                    <div className="text-xs text-muted-foreground">Match Score</div>
                  </div>
                  <div className="w-16 h-16 rounded-full border-4 border-muted flex items-center justify-center relative">
                    <svg className="absolute inset-0 w-full h-full -rotate-90">
                      <circle cx="32" cy="32" r="28" fill="none" stroke="hsl(var(--muted))" strokeWidth="4" />
                      <circle
                        cx="32" cy="32" r="28" fill="none"
                        stroke={job.score >= 85 ? "hsl(var(--success))" : job.score >= 70 ? "hsl(var(--warning))" : "hsl(var(--destructive))"}
                        strokeWidth="4"
                        strokeDasharray={`${(job.score / 100) * 176} 176`}
                        strokeLinecap="round"
                      />
                    </svg>
                    <TrendingUp className={`w-4 h-4 ${getScoreColor(job.score)}`} />
                  </div>
                </div>
              </div>

              <Progress value={job.score} className="h-1.5 mb-4" />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="flex items-center gap-1.5 mb-2 text-success">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span className="font-medium text-xs uppercase tracking-wider">Matched</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {job.matched.map((s) => (
                      <span key={s} className="agent-badge border-success/20 bg-success/10 text-success">{s}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-2 text-warning">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span className="font-medium text-xs uppercase tracking-wider">Partial</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {job.partial.map((s) => (
                      <span key={s} className="agent-badge border-warning/20 bg-warning/10 text-warning">{s}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-2 text-destructive">
                    <XCircle className="w-3.5 h-3.5" />
                    <span className="font-medium text-xs uppercase tracking-wider">Missing</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {job.missing.map((s) => (
                      <span key={s} className="agent-badge border-destructive/20 bg-destructive/10 text-destructive">{s}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default JobMatching;
