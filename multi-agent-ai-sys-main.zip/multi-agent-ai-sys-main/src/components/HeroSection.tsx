import { Upload, Zap, Brain, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = ({ onNavigate }: { onNavigate: (section: string) => void }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={heroBg} alt="" className="w-full h-full object-cover opacity-30" width={1920} height={1080} />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
      </div>

      {/* Floating orbs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-primary/10 blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-48 h-48 rounded-full bg-secondary/10 blur-3xl animate-float" style={{ animationDelay: "3s" }} />

      <div className="relative z-10 section-container text-center">
        <div className="inline-flex items-center gap-2 agent-badge border-primary/30 bg-primary/10 text-primary mb-6">
          <Zap className="w-3.5 h-3.5" />
          Multi-Agent AI System
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight mb-6 leading-tight">
          <span className="gradient-text">Intelligent</span> Resume
          <br />
          Parsing & Talent
          <br />
          <span className="gradient-text">Intelligence</span>
        </h1>

        <p className="text-muted-foreground text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
          AI-powered multi-agent system that parses resumes, normalizes skills, and performs semantic job matching — all through REST APIs.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            size="lg"
            className="glow-effect text-base px-8 py-6 rounded-xl"
            onClick={() => onNavigate("upload")}
          >
            <Upload className="w-5 h-5 mr-2" />
            Upload Resume
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="text-base px-8 py-6 rounded-xl"
            onClick={() => onNavigate("demo")}
          >
            <Brain className="w-5 h-5 mr-2" />
            View Demo
          </Button>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto">
          {[
            { label: "Formats Supported", value: "PDF, DOCX, TXT" },
            { label: "Skill Taxonomy", value: "5,000+" },
            { label: "Match Accuracy", value: "94.7%" },
            { label: "API Endpoints", value: "12+" },
          ].map((stat) => (
            <div key={stat.label} className="glass-card p-4">
              <div className="text-lg font-bold gradient-text">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
