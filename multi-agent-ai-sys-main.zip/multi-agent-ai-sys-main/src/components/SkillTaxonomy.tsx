import { Tags, ChevronRight } from "lucide-react";

const taxonomy = [
  {
    category: "Technical Skills",
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/20",
    subcategories: [
      {
        name: "Programming Languages",
        skills: [
          { name: "Python", synonyms: ["Py", "Python3"], proficiency: 92 },
          { name: "JavaScript", synonyms: ["JS", "ECMAScript"], proficiency: 88 },
          { name: "TypeScript", synonyms: ["TS"], proficiency: 85 },
        ],
      },
      {
        name: "ML / AI",
        skills: [
          { name: "TensorFlow", synonyms: ["TF"], proficiency: 78 },
          { name: "PyTorch", synonyms: ["Torch"], proficiency: 72 },
          { name: "Deep Learning", synonyms: ["DL", "Neural Networks"], proficiency: 80 },
        ],
      },
    ],
  },
  {
    category: "Cloud & DevOps",
    color: "text-secondary",
    bg: "bg-secondary/10",
    border: "border-secondary/20",
    subcategories: [
      {
        name: "Cloud Platforms",
        skills: [
          { name: "AWS", synonyms: ["Amazon Web Services"], proficiency: 85 },
          { name: "Docker", synonyms: ["Containers"], proficiency: 80 },
          { name: "Kubernetes", synonyms: ["K8s"], proficiency: 65 },
        ],
      },
    ],
  },
  {
    category: "Soft Skills",
    color: "text-warning",
    bg: "bg-warning/10",
    border: "border-warning/20",
    subcategories: [
      {
        name: "Leadership",
        skills: [
          { name: "Team Management", synonyms: ["Team Lead"], proficiency: 75 },
          { name: "Communication", synonyms: ["Interpersonal"], proficiency: 90 },
        ],
      },
    ],
  },
];

const SkillTaxonomy = () => {
  return (
    <section id="taxonomy" className="py-24 bg-muted/20">
      <div className="section-container">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 agent-badge border-secondary/30 bg-secondary/10 text-secondary mb-4">
            <Tags className="w-3.5 h-3.5" />
            Skill Normalization
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Hierarchical <span className="gradient-text">Skill Taxonomy</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Skills are mapped to a canonical taxonomy with synonym resolution and proficiency estimation.
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {taxonomy.map((cat) => (
            <div key={cat.category} className={`glass-card overflow-hidden border ${cat.border}`}>
              <div className={`px-6 py-4 ${cat.bg} flex items-center gap-3`}>
                <Tags className={`w-5 h-5 ${cat.color}`} />
                <h3 className="font-semibold">{cat.category}</h3>
              </div>
              <div className="p-6 space-y-6">
                {cat.subcategories.map((sub) => (
                  <div key={sub.name}>
                    <div className="flex items-center gap-2 mb-3">
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-muted-foreground">{sub.name}</span>
                    </div>
                    <div className="space-y-3 pl-6">
                      {sub.skills.map((skill) => (
                        <div key={skill.name} className="flex items-center gap-4">
                          <span className="text-sm font-medium w-28 shrink-0">{skill.name}</span>
                          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all duration-1000"
                              style={{
                                width: `${skill.proficiency}%`,
                                background: "var(--gradient-primary)",
                              }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground w-10 text-right">{skill.proficiency}%</span>
                          <div className="hidden sm:flex gap-1">
                            {skill.synonyms.map((s) => (
                              <span key={s} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillTaxonomy;
